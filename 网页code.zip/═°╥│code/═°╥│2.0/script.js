document.addEventListener('DOMContentLoaded', function() {
    var sliderImages = document.querySelectorAll('.slider-img');
    var currentIndex = 0;

    function showImage(index) {
        sliderImages.forEach((img, i) => {
            img.style.display = i === index ? 'block' : 'none';
            img.classList.remove('active');
        });
        sliderImages[index].classList.add('active');
    }

    document.querySelector('.prev').addEventListener('click', function() {
        currentIndex = currentIndex <= 0 ? sliderImages.length - 1 : currentIndex - 1;
        showImage(currentIndex);
    });

    document.querySelector('.next').addEventListener('click', function() {
        currentIndex = currentIndex >= sliderImages.length - 1 ? 0 : currentIndex + 1;
        showImage(currentIndex);
    });

    // 初始化显示第一张图片
    showImage(currentIndex);
});
